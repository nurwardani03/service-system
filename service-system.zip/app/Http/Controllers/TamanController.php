<?php

namespace App\Http\Controllers;

class TamanController extends Controller
{
    public function index()
    {
        return view('pages.taman');
    }
}
