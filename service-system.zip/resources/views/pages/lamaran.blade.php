@extends('layouts.app')
@section('title','Lamaran')

@section('content')
<section class="py-20 text-center">
<h1 class="text-3xl font-bold">Lamaran Page</h1>
</section>
@endsection
