<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>

    
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

    
    <link href="https://unpkg.com/aos@2.3.4/dist/aos.css" rel="stylesheet">
</head>

<body class="font-['Inter'] text-gray-800">

    <?php echo $__env->make('partials.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


</body>
<audio id="bgMusic" loop preload="auto">
  <source src="/audio/bg-music.mp3" type="audio/mpeg">
</audio>

<script src="https://unpkg.com/aos@2.3.4/dist/aos.js"></script>
<script>
  AOS.init({
    once: true,
    duration: 900,
    easing: 'ease-out-cubic',
  });

  // PARALLAX HERO & IMAGE
  window.addEventListener('scroll', () => {
    document.querySelectorAll('[data-parallax]').forEach(el => {
      const speed = el.dataset.parallax;
      el.style.transform = `translateY(${window.scrollY * speed}px)`;
    });
  });
</script>


<script>
document.addEventListener('DOMContentLoaded', () => {
  const audio = document.getElementById('bgMusic');
  audio.volume = 0.25; // lembut, profesional

  // jika sebelumnya sudah play, lanjutkan
  if (localStorage.getItem('bgMusic') === 'on') {
    audio.play().catch(()=>{});
  }

  // klik di navbar mana pun
  document.querySelectorAll('nav a, nav button').forEach(el => {
    el.addEventListener('click', () => {
      audio.play().then(() => {
        localStorage.setItem('bgMusic', 'on');
      }).catch(()=>{});
    });
  });
});
</script>
<script>
const audio = document.getElementById('bgMusic');
let vol = 0;
audio.volume = 0;

audio.addEventListener('play', () => {
  const fade = setInterval(() => {
    if (vol < 0.25) {
      vol += 0.01;
      audio.volume = vol;
    } else {
      clearInterval(fade);
    }
  }, 100);
});
</script>

</html>
<?php /**PATH C:\xampp\htdocs\service-system\resources\views/layouts/app.blade.php ENDPATH**/ ?>